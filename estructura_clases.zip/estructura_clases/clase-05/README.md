# Clase 05

Ejercicios y apuntes.
