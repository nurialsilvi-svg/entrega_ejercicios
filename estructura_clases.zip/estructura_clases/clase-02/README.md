# Clase 02

Ejercicios y apuntes.
