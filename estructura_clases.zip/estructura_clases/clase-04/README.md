# Clase 04

Ejercicios y apuntes.
