# Clase 08

Ejercicios y apuntes.
