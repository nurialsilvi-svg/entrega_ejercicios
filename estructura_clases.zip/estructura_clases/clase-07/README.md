# Clase 07

Ejercicios y apuntes.
