# Clase 06

Ejercicios y apuntes.
