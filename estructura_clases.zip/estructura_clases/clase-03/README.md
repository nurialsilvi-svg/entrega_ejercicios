# Clase 03

Ejercicios y apuntes.
