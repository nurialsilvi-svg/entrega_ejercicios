# Clase 01

Ejercicios y apuntes.
